public enum TransferState {
  CONNECTING,
  ESTABLISHED,
  DISCONNECTING,
  CLOSED
}
