Pasta que contém os ficheiros em bruto após transferência.
Estes ficheiros podem ser apagados após transferência uma vez que não fazem diferença.
